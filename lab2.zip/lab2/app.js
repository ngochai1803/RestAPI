//inport thu vien
const express=require('express');
const mongoose=require('mongoose');
const SinhVien=require('./singvienmodle');
//tao doi tuong express
const app=express();

//ket noi voi csdl
mongoose.connect('mongodb://localhost:27017/admin',{
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(()=>{
    console.log("da ket not thanh cong voi mongoDB");
}).catch((err)=>{
    console.error(err);//in ra loi
});
//khi nguoi dung goi localhost:8080/sinhvien => doc du lieu to CSDL
app.get('/sinhvien',async (rep,res)=>{
    try{
        const sinhviens = await SinhVien.find();//doc du lieu tu csdl
        res.json(sinhviens);//chuyen du lieu sang json
        console.log(sinhviens);//in ket qua ra log
    }
    catch(err){
        console.error(err);//in ra loi
        res.status(500).json({error:'Internal Server Error'});//tra ve loi cho nguoi dung
    }
});
//tao cong dich vu
const PORT=process.env.PORT||8080;
//server lang nghe
app.listen(PORT,()=>{
    console.log('server dang chay o cong 8080');
});