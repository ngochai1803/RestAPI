const mongoose=require('mongoose');//inport thu vien
const SinhVienSchema=new mongoose.Schema({
    id:{
        type: String,
        required: true
    },
    name:{
        type: String,
        required: true
    },
});
const SinhVien=mongoose.model('students',SinhVienSchema);
module.exports=SinhVien;