package com.hehe.lab4_retrofit;

public class SvrResponseSanPham {
    //ket qua server tra ve
    private SanPham sanphams;
    private String message;

    public SanPham getSanphams() {
        return sanphams;
    }

    public String getMessage() {
        return message;
    }

}
