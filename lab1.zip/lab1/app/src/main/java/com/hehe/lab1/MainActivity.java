package com.hehe.lab1;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {
    FirebaseFirestore database;
    Button btnThem,btnSua,btnXoa,btnHien;
    TextView tvResultThem, tvResultSua, tvResultXoa,tvResultHien;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvResultThem = findViewById(R.id.tvResultThem);
        tvResultSua = findViewById(R.id.tvResultSua);
        tvResultXoa = findViewById(R.id.tvResultXoa);
        tvResultHien = findViewById(R.id.tvResultHien);

        database = FirebaseFirestore.getInstance(); // khoi tao dâtbase
        btnThem = findViewById(R.id.btnThem);
        btnSua = findViewById(R.id.btnSua);
        btnXoa = findViewById(R.id.btnXoa);
        btnHien = findViewById(R.id.btnHien);


        btnThem.setOnClickListener(v -> {
            insertFirebase(tvResultThem);
        });

        btnSua.setOnClickListener(v ->{
            updateFirebase(tvResultSua);
        });
        btnXoa.setOnClickListener(v ->{
            deleteFirebase(tvResultXoa);
        });
        btnHien.setOnClickListener(v ->{
            SelectDataFromFirebase(tvResultHien);
        });
    }
    String id="";
    List list = null;


    public void insertFirebase(TextView tvResult){
        id= UUID.randomUUID().toString();

        list = new List(id,"Cá vàng","Cá màu vàng");
//
        HashMap<String, Object> mapslish = list.convertHashMap();
        // insẻt vao database
        database.collection("LIST").document(id)
                .set(mapslish) // doi tuong can insert
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        MainActivity.this.tvResultThem.setText("Thêm thành công");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                      tvResultThem.setText(e.getMessage());
                    }
                });
    }
    public void updateFirebase(TextView tvResultSua){
        id="a194f507-2187-4ec7-9770-dcb1aafa691f";
        list = new List(id,"sua ten", "sua tieu de");
        database.collection("LIST").document(list.getId()).update(list.convertHashMap()).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                MainActivity.this.tvResultSua.setText("Sua Thanh cong");
            }
        }). addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
              MainActivity.this.tvResultSua.setText(e.getMessage());
            }
        });

    }

    public void deleteFirebase(TextView tvResult){
        id="a194f507-2187-4ec7-9770-dcb1aafa691f";
        database.collection("List").document(id)
                .delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        tvResultXoa.setText("Xoa thanh cong");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tvResultXoa.setText(e.getMessage());
                    }
                });
    }

    String strResult="";
    public ArrayList<List> SelectDataFromFirebase(TextView tvResult){
        ArrayList<List> list=new ArrayList<>();
        database.collection("List")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if(task.isSuccessful()){//sau khi lay du lieu thanh cong
                            strResult="";
                            //doc theo tung dong du lieu
                            for(QueryDocumentSnapshot document: task.getResult()){
                                //chuyen dong doc duoc sang doi tuong
                                List list1 = document.toObject(List.class);
                                //chuyen doi tuong thanhchuoi
                                strResult +="id: "+list1.getId()+"\n";
                                list.add(list1);//them vao list
                            }
                            //hien thi ket qua
                            tvResultHien.setText(strResult);
                        }
                        else {
                            tvResultHien.setText("Doc du lieu that bai");
                        }

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        tvResultHien.setText(e.getMessage());
                    }
                });
        return list;
    }
}