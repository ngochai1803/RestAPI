package com.hehe.lab1;

import java.util.HashMap;

public class List {
    private String id,name, description;


    public List() {
    }

    public List(String id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    public HashMap<String, Object> convertHashMap(){
        HashMap<String,Object> work=new HashMap<>();
        work.put("id", id);
        work.put("name", name);
        work.put("description",description);
        return work;
    }
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
